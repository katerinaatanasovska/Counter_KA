package com.example.productscounter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class MainActivity extends AppCompatActivity {
EditText editText1, editText2;
TextView textView;
ArrayList<Product>products;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText1=(EditText)findViewById(R.id.editText1);
        editText2=(EditText)findViewById(R.id.editText2);
        textView=(TextView) findViewById(R.id.textView);
        products=new ArrayList<Product>();
        try {
            LoadData(ex);
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
    }
    public void btnAdd(){
       String EditText1=editText1.getText().toString();
       String EditText2=editText2.getText().toString();

       Product product=new Product();
       products.add(product);

       setTextToTextView();
    }

    private void setTextToTextView() {
        String text="";
        for(int i=0; i<products.size();i++)
        {

            text=text+ products.get(i).getProduct() +" " + products.get(i).getQuantity()+"\n";
        }
        textView.setText(text);

    }
    public void LoadData(Throwable ex) throws FileNotFoundException {
        products.clear();

        File file = getApplicationContext().getFileStreamPath("data.txt");
        String lineFromFile = null;
        if (file.exists()) {
            try {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(openFileInput("data.txt")))) {
                    while (true) {
                        try {
                            if (!((lineFromFile = reader.readLine()) != null)) break;
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        StringTokenizer tokens = new StringTokenizer(lineFromFile, ",");
                        Product product = new Product((tokens.nextToken()), tokens.nextToken());
                        products.add(product);
                    }
                    reader.close();
                } catch (IOException ex) {

                }
                Toast.makeText(MainActivity.this, ex.getMessage(), Toast.LENGTH_SHORT).show();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        try {
                OutputStreamWriter outputFile;
                try (FileOutputStream fileOutputStream= new FileOutputStream("data.txt")) {
                    outputFile = new OutputStreamWriter(fileOutputStream);
                }
                for (int i = 0; i < products.size(); i++) {
                    outputFile.write(products.get(i).getProduct() + "," + products.get(i).getQuantity() + "\n");
                }
                outputFile.flush();
                outputFile.close();
                Toast.makeText(MainActivity.this, "Successfully saved!", Toast.LENGTH_SHORT).show();

            } catch (IOException e) {
                Toast.makeText((MainActivity.this), e.getMessage(), Toast.LENGTH_SHORT).show();

            }

        }

    public void btnAdd(View view) {
    }

    public void btnSave(View view) {
    }
}

